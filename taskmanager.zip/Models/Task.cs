using System;
using System.ComponentModel.DataAnnotations;

namespace TaskManagementApp.Models
{
    public class Task
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public DateTime DueDate { get; set; }

        [Range(1, 3)]
        public int Priority { get; set; } // 1=High, 2=Medium, 3=Low

        public bool IsCompleted { get; set; }
    }
}
